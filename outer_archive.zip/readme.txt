Это внешний архив, содержащий inner_archive.zip
